package com.example.timer;

public class SequenceAdapter extends RecyclerView. {
}
